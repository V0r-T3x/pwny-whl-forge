2.3.0
-----

* New: Support for Spectra 4.0" boards.

2.2.1
-----

* BugFix: Correct palette count for new boards, so 4-colour prepared images are not dithered.

2.2.0
-----

* New: Support for 4-colour (Black/White/Red/Yellow) Inky and Inky wHAT boards.
* BugFix: Fixed Spectra6 colour constants (swapped green and blue)
* Enhancement: Improve Spectra6 handling of palette mode images.

2.1.0
-----

* New: Support for Spectra 13.3" and 7.3" boards.

2.0.0
-----

* Rewrite to gpiod/gpiodevice.
* Repackage to hatch/pyproject.toml.
* Breaking: Fixes to chip-select behaviour across all boards

1.5.0
-----

* New: inky impression 7.3" support.
* BugFix: WIDTH / HEIGHT set on uc8159.

1.4.0
-----

* New: inky SSD1683 support for WHAT variant

1.3.2
-----

* BugFix: (ish) handle busy_wait failure cases for UC8159 (Inky Impression)

1.3.1
-----

* BugFix: unbreak UC8159

1.3.0
-----

* New: inky UC8159 support for 4" 640x400 display variant
* BugFix: fix set_image so it doesn't break set_pixel
* New: Added --simulate <board> to "auto()", so auto examples can simulate a chosen board

1.2.2
-----

* BugFix: Raise Impression/7Color/UC8159 busy wait timeout from 15s to 30s

1.2.1
-----

* BugFix: inky high-temp red fix
* Enhancement: SSD1608 (250x122) set_border support

1.2.0
-----

* New: inky impression set_border support
* BugFix: inky impression orange colour
* BugFix: inky impression invalid arg bug for Python 2
* New: inky impression simulator

1.1.1
-----

* Enhancement: drive UC81559 CS with GPIO to avoid conflict with Grow workaround
* Add 7-colour/UC8159 specifics to EEPROM
* BugFix: define UC8159 colour and size constants in class
* BugFix: fix auto to grab args properly, support UC8159 and fallback gracefully

1.1.0
-----

* New: Support for UC8159-based 7-colour 600x448 display
* Enhancement: auto now includes options for fallback
* Enhancement: EEPROM can now give text string for display variant

1.0.2
-----

* Enhancement: Always install Pi dependencies

1.0.1
-----

* Enhancement: Tweak setup.py extras for easier dependency install

1.0.0
-----

* New: Support for SSD1608-based displays
* New: Mock Inky pHAT and wHAT displays
* New: Automatic Inky detection and class constructor
* Enhancement: Support for alternate i2c_bus when reading eeprom
* Enhancement: Support for alternate spi_bus
* Enhancement: Support for alternate GPIO driver
* Enhancement: Replaced sys.exit calls with ImportError
* Enhancement: Improved docstrings

0.0.5
-----

* Enhancement: Added support for red/b/w high-temp Inky wHAT

0.0.4
-----

* BugFix: Reverted normal red LUTs to correct values

0.0.3
-----

* Enhancement: Added support for display variant detection
* Enhancement: Added DocStrings
* BugFix: Fixed set_border for all colours

0.0.2
-----

* BugFix: Yellow Inky pHAT now yellow instead of brown/black
* Enhancement: Performance tweak for set_image

0.0.1
-----

* Initial Release
